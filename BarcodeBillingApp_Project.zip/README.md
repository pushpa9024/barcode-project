# Barcode Billing App

An Android application to scan barcodes, fetch product details, and generate invoices.
